<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Employees</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">

        <!-- jQuery library -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

        <!-- Latest compiled JavaScript -->
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <!-- Styles -->
    </head>
    <body class="antialiased">
        <div>
            <div class="row">
                <div style="display:flex; justify-content:space-around;">
                    <h3>List Of Employees</h3>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
                        Add New Employees
                      </button>
                </div>
                <div><table class="table">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Name</th>
                        <th scope="col">Address</th>
                        <th scope="col">Salary</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                        @foreach ($employees as $data)
                            <tr>
                                <th scope="row">{{ $data['id']}}</th>
                                <td>{{  $data['name']}}</td>
                                <td>{{  $data['address']}}</td>
                                <td>{{  $data['salary']}}</td>
                                <td>
                                    <button><i class="fas fa-eye"></i></button>
                                    <button><i class="fa-solid fa-pen"></i></button>
                                    <button><i class="fa-solid fa-trash"></i></button>
                                </td>
                            </tr>
                        @endforeach

                    </tbody>
                  </table></div>
            </div>
        </div>
          <!-- Modal -->
          <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLongTitle">Add New Employees</h5>
                    <form action="/action_page.php">
                        <div class="mb-3 mt-3">
                        <label for="email" class="form-label">Name:</label>
                        <input type="name" class="form-control" id="email" name="email">
                        </div>
                        <div class="mb-3">
                        <label for="pwd" class="form-label">Address:</label>
                        <input type="address" class="form-control" id="pwd" name="pswd">
                        </div>
                        <div class="mb-3">
                            <label for="pwd" class="form-label">Salary:</label>
                            <input type="salary" class="form-control" id="pwd" name="pswd">
                            </div>
                    </form>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary">Save changes</button>
                </div>
              </div>
            </div>
          </div>
    </body>
</html>
